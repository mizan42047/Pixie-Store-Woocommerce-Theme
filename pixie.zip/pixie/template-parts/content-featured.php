<?php global $product; ?>
<a href="<?php echo $product->get_permalink(); ?>">
    <div class="featured-item">
        <img src="<?php echo wp_get_attachment_url($product->get_image_id()); ?>" alt="Item 1">
        <h4><?php echo $product->get_title(); ?></h4>
        <h6><?php echo get_woocommerce_currency_symbol() ?><?php echo $product->get_price(); ?></h6>
    </div>
</a>