<?php
/**
 * Template Name:Two colum Page Layout
 */

 ?>
 <?php get_header(); ?>

<div class="about-page">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <div class="line-dec"></div>
              <h1><?php esc_html_e(single_post_title(),'pixie'); ?></h1>
            </div>
          </div>
          <div class="col-md-6">
            <div class="left-image">
            <?php if(has_post_thumbnail()): ?>
              <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php esc_attr_e(single_post_title(),'pixie'); ?>">
            <?php endif; ?>  
            </div>
          </div>
          <div class="col-md-6">
            <div class="right-content">
              <?php __(the_content(),'pixie'); ?>
            </div>
          </div>
        </div>
      </div>
    </div>

<?php get_footer(); ?>