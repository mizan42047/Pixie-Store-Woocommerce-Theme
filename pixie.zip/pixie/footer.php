<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Pixie
 */

?>

	<!-- Subscribe Form Starts Here -->
    <div class="subscribe-form">
      <div class="container">
        <div class="row">
          <?php if(get_theme_mod('subscribe_title')): ?>
          <div class="col-md-12">
            <div class="section-heading">
              <div class="line-dec"></div>
              <h1 class="subscribe_title"><?php esc_html_e(get_theme_mod('subscribe_title',true),'pixie'); ?></h1>
            </div>
          </div>
          <?php endif; ?>

          <div class="col-md-8 offset-md-2">
            <div class="main-content">
              <?php if(get_theme_mod('subscribe_description')): ?>
              <p class="subscribe_description"><?php esc_html_e(get_theme_mod('subscribe_description',true),'pixie'); ?></p>
              <?php endif; ?>
              <?php if(get_theme_mod('subscribe_form_shortcode')): ?>
              <div class="container">
                <?php echo do_shortcode(sanitize_text_field( get_theme_mod('subscribe_form_shortcode') )); ?>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Subscribe Form Ends Here -->
	<!-- Footer Starts Here -->
    <div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="logo">
              <?php 
              if(has_custom_logo()){
                the_custom_logo();
              }else{?>
              <a class="text-primary mb-3" href="<?php echo esc_url(site_url()); ?>">
                <h1><?php bloginfo('name'); ?></h1>
              </a>
              <?php }
              ?>
            </div>
          </div>

          <div class="col-md-12">
            <div class="footer-menu">
              <?php 
              
              $footer_menu = wp_nav_menu([
                'theme_location' => 'menu-2',
                'menu'           => 'menu-2',
                'manu_class'     => '',
                'echo'           => false,
              ]);

              $footer_menu = str_replace('nav-link','',$footer_menu);
              echo $footer_menu;
              
              ?>
            </div>
          </div>
          <div class="col-md-12 text-center">
              <?php 
              if(is_active_sidebar('sidebar-2')){
                dynamic_sidebar('sidebar-2');
              }
              
              ?>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer Ends Here -->


    <!-- Sub Footer Starts Here -->
    <?php if(get_theme_mod('copyright_text')): ?>
    <div class="sub-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="copyright-text">
              <p class="copyright_text">
                <?php esc_html_e(get_theme_mod('copyright_text',true),'pixie'); ?>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>
    <!-- Sub Footer Ends Here -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
