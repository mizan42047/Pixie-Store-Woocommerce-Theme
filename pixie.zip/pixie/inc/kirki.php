<?php
define('CONFIGID','kirki-config-id');
define('PANELID','pixie-panel-id');
define('BANNERID','pixie-banner-section-id');
define('PIXIEHEADERSEC','pixie-header-section-id');
define('PIXIESUBSCRIBESEC','pixie-subscribe-section-id');
define('PIXIECOPYSEC','pixie-copyright-section-id');
define('CONTACTSEC','pixie-contact-section-id');


/**
 * Kirki Config
 */

Kirki::add_config( CONFIGID, array(
	'capability'    => 'edit_theme_options',
	'option_type'   => 'theme_mod',
) ); 

/**
 * Pixie Panel
 */

Kirki::add_panel( PANELID, array(
    'priority'    => 10,
    'title'       => esc_html__( 'PIXIE', 'pixie' ),
) );

/**
 * Pixie Banner Section
 */

Kirki::add_section( BANNERID, array(
    'title'          => esc_html__( 'Pixie Banner', 'pixie' ),
    'panel'          => PANELID,
    'priority'       => 160,
) );

/**
 * Banner Image
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'image',
	'settings'    => 'banner_image',
	'label'       => esc_html__( 'Banner Image', 'pixie' ),
	'section'     => BANNERID,
	'default'     => 'https://plestant.sirv.com/banner-bg.jpg',
] );

/**
 * Banner Title
 */
Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'banner_title',
	'label'    => esc_html__( 'Banner Title', 'pixie' ),
	'section'  => BANNERID,
	'default'  => esc_html__( 'Pixie Fashion Store', 'pixie' ),
	'priority' => 10,
] );

/**
 * Banner Editor
 */

Kirki::add_field( CONFIGID, [
	'type'        => 'editor',
	'settings'    => 'banner_content',
	'label'       => esc_html__( 'Banner Content', 'pixie' ),
	'section'     => BANNERID,
	'default'     => 'Address : Kadamtali Police Station, Dhaka,Bangladesh',
] );

/**
 * Banner Button Text
 */
Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'banner_btn_text',
	'label'    => esc_html__( 'Button Text', 'pixie' ),
	'section'  => BANNERID,
	'default'  => esc_html__( 'Start Shoping', 'pixie' ),
	'priority' => 10,
] );

/**
 * Pixie Header Section
 */

Kirki::add_section( PIXIEHEADERSEC, array(
    'title'          => esc_html__( 'Pixie Header', 'pixie' ),
    'panel'          => PANELID,
    'priority'       => 160,
) );

/**
 * header notice Text
 */
Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'header_notice_text',
	'label'    => esc_html__( 'Notice', 'pixie' ),
	'section'  => PIXIEHEADERSEC,
	'default'  => esc_html__( '40% off for using coupon MIJANDEV40', 'pixie' ),
	'priority' => 10,
	'partial_refresh'    => [
		'header_notice_text' => [
			'selector'        => '.header_notice_text',
			'render_callback' => function() {
				return get_theme_mod('header_notice_text');
			},
		],
	],
] );

/**
 * Pixie Subscribe Section
 */

Kirki::add_section( PIXIESUBSCRIBESEC, array(
    'title'          => esc_html__( 'Subscribe', 'pixie' ),
    'panel'          => PANELID,
    'priority'       => 160,
) );

/**
 * Subscribe heading
 */
Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'subscribe_title',
	'label'    => esc_html__( 'Title', 'pixie' ),
	'section'  => PIXIESUBSCRIBESEC,
	'default'  => esc_html__( 'Subscribe on PIXIE now!', 'pixie' ),
	'priority' => 10,
	'partial_refresh'    => [
		'subscribe_title' => [
			'selector'        => '.subscribe_title',
			'render_callback' => function() {
				return get_theme_mod('subscribe_title');
			},
		],
	],
] );

/**
 * Subscribe description
 */
Kirki::add_field( CONFIGID, [
	'type'     => 'textarea',
	'settings' => 'subscribe_description',
	'label'    => esc_html__( 'Description', 'pixie' ),
	'section'  => PIXIESUBSCRIBESEC,
	'default'  => esc_html__( 'Integer vel turpis ultricies, lacinia ligula id, lobortis augue. Vivamus porttitor dui id dictum efficitur. Phasellus vel interdum elit.', 'pixie' ),
	'priority' => 10,
	'partial_refresh'    => [
		'subscribe_description' => [
			'selector'        => '.subscribe_description',
			'render_callback' => function() {
				return get_theme_mod('subscribe_description');
			},
		],
	],
] );

/**
 * Subscribe form shortcode
 */
Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'subscribe_form_shortcode',
	'label'    => esc_html__( 'Form Shortcode', 'pixie' ),
	'section'  => PIXIESUBSCRIBESEC,
	'default'  => esc_html__( '', 'pixie' ),
	'priority' => 10,
] );

/**
 * Pixie Contact Section
 */

Kirki::add_section( CONTACTSEC, array(
    'title'          => esc_html__( 'Conatct', 'pixie' ),
    'panel'          => PANELID,
    'priority'       => 160,
	'active_callback' => function(){
		if(is_page_template('contact-template.php')){
			return true;
		}else{
			return false;
		}
	}
) );


/**
 * Map Address
 */
Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'map_address',
	'label'    => esc_html__( 'Map Adress', 'pixie' ),
	'section'  => CONTACTSEC,
	'default'  => esc_html__( 'kadamtali police station', 'pixie' ),
	'priority' => 10,

] );
/**
 * Map Zoom
 */
Kirki::add_field( CONFIGID, [
	'type'     => 'number',
	'settings' => 'map_zoom_number',
	'label'    => esc_html__( 'Map Zoom', 'pixie' ),
	'section'  => CONTACTSEC,
	'default'  => esc_html__( absint(14), 'pixie' ),
	'priority' => 10,
	'partial_refresh'    => [
		'map_zoom_number' => [
			'selector'        => '.map_zoom_number',
			'render_callback' => function() {
				return get_theme_mod('map_zoom_number');
			},
		],
	],
] );

/**
 * Contact Form Shortcode
 */
Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'contact_form_title',
	'label'    => esc_html__( 'Contact Title', 'pixie' ),
	'default'  => __('Contact Us','pixie'),
	'section'  => CONTACTSEC,
	'priority' => 10,
] );

/**
 * Contact Form Shortcode
 */
Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'contact_form_shortcode',
	'label'    => esc_html__( 'Form Shortcode', 'pixie' ),
	'section'  => CONTACTSEC,
	'priority' => 10,
] );



/**
 * Pixie Copyright Section
 */

Kirki::add_section( PIXIECOPYSEC, array(
    'title'          => esc_html__( 'Copyright', 'pixie' ),
    'panel'          => PANELID,
    'priority'       => 160,
) );


/**
 * Copyright text
 */
Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'copyright_text',
	'label'    => esc_html__( 'Copyright', 'pixie' ),
	'section'  => PIXIECOPYSEC,
	'default'  => esc_html__( 'COPYRIGHT @ 2021 Mijanur Rahman for theme and for design Tooplate', 'pixie' ),
	'priority' => 10,
	'partial_refresh'    => [
		'copyright_text' => [
			'selector'        => '.copyright_text',
			'render_callback' => function() {
				return get_theme_mod('copyright_text');
			},
		],
	],
] );



