<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Pixie
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'pixie' ); ?></a>

	<!-- Pre Header -->
  <?php if(get_theme_mod('header_notice_text')): ?>
    <div id="pre-header">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <span class="header_notice_text">
              <?php esc_html_e(get_theme_mod('header_notice_text',true),'pixie'); ?>
            </span>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
      <div class="container">
        <?php 
        if(has_custom_logo()){
          $logo = get_custom_logo();
          $logo = str_replace('custom-logo-link','custom-logo-link navbar-brand',$logo);
          echo $logo;
        }else{
          ?>
          <a class="navbar-brand text-primary mb-3" href="<?php echo esc_url(site_url()); ?>">
            <h1><?php bloginfo('name'); ?></h1>
          </a>
          <?php
        }
        ?>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <?php 
            wp_nav_menu([
              'theme_location' => 'menu-1',
              'menu'           => 'menu-1',
              'menu_class'     => 'navbar-nav ml-auto',
            ])
          ?>
        </div>
      </div>
    </nav>
