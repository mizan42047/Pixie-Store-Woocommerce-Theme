<?php get_header(); ?>
<!-- Page Content -->
<!-- Banner Starts Here -->
<?php if (get_theme_mod('banner_image')) : ?>
  <style>
    .banner {
      background-image: url('<?php echo esc_url(get_theme_mod('banner_image', true)); ?>');
    }
  </style>
<?php endif; ?>
<div class="banner">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="caption">
          <?php if (get_theme_mod('banner_title')) : ?>
            <h2><?php esc_html_e(get_theme_mod('banner_title', true), 'pixie'); ?></h2>
            <div class="line-dec"></div>
          <?php endif; ?>
          <?php if (get_theme_mod('banner_content')) : ?>
            <p><?php echo wp_kses(get_theme_mod('banner_content', true), 'pixie'); ?></p>
          <?php endif; ?>
          <div class="main-button">
            <?php if (get_theme_mod('banner_btn_text')) : ?>
              <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>"><?php esc_html_e(get_theme_mod('banner_btn_text', true), 'pixie'); ?></a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Banner Ends Here -->

<!-- Featured Starts Here -->
<div class="featured-items">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="section-heading">
          <div class="line-dec"></div>
          <h1>Featured Items</h1>
        </div>
      </div>
      <div class="col-md-12">
        <div class="owl-carousel owl-theme">
          <?php

          // The tax query
          $tax_query[] = array(
            'taxonomy' => 'product_visibility',
            'field'    => 'name',
            'terms'    => 'featured',
            'operator' => 'IN', // or 'NOT IN' to exclude feature products
          );

          // The query
          $products = wc_get_products(array(
            'tax_query'           => $tax_query, // <===
            'limit'               => '10',
          ));

          foreach ($products as $product) {
            get_template_part('template-parts/content','featured');
          }?>
        </div>
        </ul>
      </div>
    </div>
  </div>
</div>
<!-- Featred Ends Here -->

<?php get_footer(); ?>

</body>

</html>