<?php

/**
 * 
 * Template Name:Contact
 * 
 */

get_header();
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">

            <div class="contact-page">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <?php if(get_theme_mod('contact_form_title')): ?>
                            <div class="section-heading">
                                <div class="line-dec"></div>
                                <h1><?php esc_html_e(get_theme_mod('contact_form_title',true),'pixie'); ?></h1>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php 
                        if(get_theme_mod('map_address')){
                            $address = sanitize_text_field(get_theme_mod('map_address',true));
                        }else{
                            $address = esc_html('kadamtali police station');
                        }

                        $map_zoom = (get_theme_mod('map_zoom_number'))?absint(get_theme_mod('map_zoom_number',true)):14;
                        
                        ?>
                        <div class="col-md-6">
                            <div id="map">
                                <iframe class="map_zoom_number" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php echo $address; ?>+(Pixie%20Store)&amp;t=&amp;z=<?php echo $map_zoom; ?>&amp;ie=UTF8&amp;iwloc=B&amp;output=embed" width="100%" height="430px" frameborder="0" style="border:0" allowfullscreen></iframe>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="right-content">
                                
                                <?php 
                                $form = (get_theme_mod('contact_form_shortcode'))?sanitize_text_field(get_theme_mod('contact_form_shortcode')):false;
                                echo do_shortcode($form); 
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php
get_footer();
