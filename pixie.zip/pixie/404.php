<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Pixie
 */

get_header();
?>

	<main id="primary" class="container mt-5">

		<section class="row">
			<div class="col-md-12 py-5">
			<header class="page-header text-center">
				<h1 class="page-title text-center text-warning"><?php esc_html_e( 'Oops! We can not found anything', 'pixie' ); ?></h1>
				<a href="<?php echo esc_url(site_url()); ?>"><i class="fa fa-arrow-left"> </i> <?php esc_html_e('Go Home','pixie'); ?></a>
			</header><!-- .page-header -->
			</div>
		</section><!-- .error-404 -->

	</main><!-- #main -->

<?php
get_footer();
